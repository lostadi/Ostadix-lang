"""
Nix derivation backend — producer of ODerivation.

The Python-side counterpart to backends/nix_drv_shim.py. This backend powers
`drv^(...)_drv` blocks when the in-process Python evaluator handles the
expression (as opposed to the Rust runtime which uses the wire-format shim).

Semantics mirror the shim exactly:
    Nix expression source
      → nix-instantiate           (produces /nix/store/...-foo.drv)
      → nix derivation show        (produces canonical JSON)
      → ODerivation                (typed OValue with the .drv structure)

This is the L*-layer access point for the materialization category. Two
semantically identical Nix expressions instantiate to the same .drv — and
because we operate at this layer rather than on the raw expression, O-lang
can reason about builds canonically without the contingent representation
fiber that the expression form carries.

Example:
    let foo = drv^(
      derivation {
        name    = "hello";
        builder = "/bin/sh";
        args    = [ "-c" "echo hi > $out" ];
        system  = "x86_64-linux";
      }
    )_drv

    # foo : ODerivation
    # foo.drv_path : "/nix/store/...-hello.drv"
    # foo.outputs  : {"out": DerivationOutput(path="/nix/store/...-hello")}

The backend is stateless; each evaluation is a fresh `nix-instantiate`. The
discipline argues for this: every .drv has a content-addressed identity, so
state across invocations is a category error — identical inputs produce
identical .drvs regardless of when.
"""

from __future__ import annotations

import json
import subprocess
from typing import Any, Dict, List

from ..ovalue import (
    DerivationOutput, ODerivation, OValue,
)
from .nix_backend import _render_nix


def _instantiate_to_drv_path(expr_source: str) -> str:
    """Run nix-instantiate; return the .drv store path."""
    cmd = ["nix-instantiate", "--expr", expr_source]
    try:
        result = subprocess.run(
            cmd,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=120,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "nix-instantiate not found. Install Nix to use drv^(...)_drv blocks."
        )

    if result.returncode != 0:
        raise RuntimeError(
            f"nix-instantiate failed (exit {result.returncode}):\n"
            f"STDERR:\n{result.stderr}\nSTDOUT:\n{result.stdout}"
        )

    lines = [ln.strip() for ln in result.stdout.splitlines() if ln.strip()]
    if not lines:
        raise RuntimeError(
            "nix-instantiate produced no output. The expression may not "
            "evaluate to a derivation."
        )

    drv_path = lines[0]
    if not (drv_path.startswith("/nix/store/") and drv_path.endswith(".drv")):
        raise RuntimeError(
            f"nix-instantiate produced unexpected path: {drv_path!r}. "
            "Expected /nix/store/...-foo.drv."
        )
    return drv_path


def _show_derivation(drv_path: str) -> Dict[str, Any]:
    """Run `nix derivation show` and return the inner derivation body."""
    cmd = [
        "nix",
        "--extra-experimental-features", "nix-command",
        "derivation", "show",
        drv_path,
    ]
    try:
        result = subprocess.run(
            cmd,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=60,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "nix executable not found. Install Nix to use drv^(...)_drv blocks."
        )

    if result.returncode != 0:
        raise RuntimeError(
            f"nix derivation show failed (exit {result.returncode}):\n"
            f"STDERR:\n{result.stderr}\nSTDOUT:\n{result.stdout}"
        )

    parsed = json.loads(result.stdout)
    if drv_path not in parsed:
        raise RuntimeError(
            f"nix derivation show output missing expected key {drv_path!r}; "
            f"got: {list(parsed)}"
        )
    return parsed[drv_path]


def _normalize_input_drvs(input_drvs: Dict[str, Any]) -> Dict[str, List[str]]:
    """Normalize the inputDrvs field across Nix versions.

    Older Nix:  {"/nix/store/x.drv": ["out", "dev"]}
    Newer Nix:  {"/nix/store/x.drv": {"outputs": ["out"], "dynamicOutputs": {}}}

    We collapse to the older shape so downstream code sees a uniform format.
    """
    out: Dict[str, List[str]] = {}
    for drv, value in input_drvs.items():
        if isinstance(value, list):
            out[drv] = list(value)
        elif isinstance(value, dict):
            out[drv] = list(value.get("outputs", []))
        else:
            out[drv] = []
    return out


def _body_to_derivation(drv_path: str, body: Dict[str, Any]) -> ODerivation:
    """Convert `nix derivation show` body JSON into an ODerivation.

    The output values are converted into DerivationOutput records; CA-derivation
    hash metadata flows through structurally rather than being flattened.
    """
    outputs_tuple = tuple(
        (name, DerivationOutput(
            path=      info.get("path", ""),
            hash_algo= info.get("hashAlgo"),
            hash=      info.get("hash"),
        ))
        for name, info in body.get("outputs", {}).items()
    )
    input_drvs_normalized = _normalize_input_drvs(body.get("inputDrvs", {}))
    input_drvs_tuple = tuple(
        (drv, tuple(outs)) for drv, outs in input_drvs_normalized.items()
    )
    env_tuple = tuple(
        (k, v) for k, v in body.get("env", {}).items()
    )

    return ODerivation(
        drv_path=   drv_path,
        outputs=    outputs_tuple,
        input_drvs= input_drvs_tuple,
        input_srcs= tuple(body.get("inputSrcs", [])),
        system=     body.get("system", ""),
        builder=    body.get("builder", ""),
        args=       tuple(body.get("args", [])),
        env=        env_tuple,
    )


class NixDrvBackend:
    """Backend for drv^(...)_drv blocks. Produces ODerivation values."""

    name = "drv"

    def make_env(self) -> Any:
        return None  # stateless — see module docstring on why

    def render_child(self, v: OValue) -> str:
        """Reuse the Nix renderer so OValues from prior blocks can be spliced
        into the drv body as Nix expressions (a list of OStr becomes a Nix list
        of strings, etc.)."""
        return _render_nix(v)

    def evaluate(self, body: str, env: Any) -> OValue:
        drv_path = _instantiate_to_drv_path(body)
        body_json = _show_derivation(drv_path)
        return _body_to_derivation(drv_path, body_json)
