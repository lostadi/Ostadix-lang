// ─────────────────────────────────────────────────────────────────────────────
// value.rs
//
// The OValue type system — the universal intermediate representation of the O
// language runtime. Every value that crosses a language boundary in an O
// program is an OValue. No exceptions.
//
// This file has zero dependencies on parsing, evaluation, or process
// management. It is the pure data layer. It answers one question: what IS a
// value in O?
//
// The answer is a sum type with eight variants. That's it. That's the entire
// O value universe. All inter-language richness lives in how backends
// serialize their native values into these eight shapes, and deserialize them
// back out. The wire protocol (JSON over stdin/stdout) is also defined here,
// because the encoding and the type are inseparable.
//
// Design note on OInt: we use i64 for the MVP. This is a known limitation —
// arbitrary precision integers exist in Python, Haskell, and Lisp, and they
// cannot round-trip through i64 without loss. The fix (num-bigint) is
// straightforward and will be added before the first public release.
// ─────────────────────────────────────────────────────────────────────────────

use std::collections::HashMap;
use std::fmt;

use anyhow::{bail, Result};
use base64::{engine::general_purpose::STANDARD as B64, Engine};
use serde::{Deserialize, Serialize};
use serde_json::Value as JsonValue;


// ═════════════════════════════════════════════════════════════════════════════
// SECTION 1: The OValue Sum Type
// ═════════════════════════════════════════════════════════════════════════════

/// A single output of a Nix derivation.
///
/// In the simplest input-addressed case this carries just the realized store
/// path. CA-derivations and fixed-output derivations additionally carry the
/// hash algorithm and the expected output hash; both are optional so the
/// shape matches `nix derivation show` JSON for both addressing schemes.
///
/// Serializes as `{"path": "...", "hashAlgo": "...", "hash": "..."}` matching
/// Nix's own JSON output format. The optional fields are skipped on the wire
/// when None so the common case stays compact.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DerivationOutput {
    pub path: String,
    #[serde(rename = "hashAlgo", skip_serializing_if = "Option::is_none", default)]
    pub hash_algo: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none", default)]
    pub hash: Option<String>,
}

/// The complete universe of values in the O language runtime.
///
/// Every value that passes between language backends — from Python to HTML,
/// from Racket to LaTeX, from Haskell to Rust — is one of these variants.
/// The type is the wire protocol: `serde` derives the JSON encoding
/// automatically from the struct shape.
///
/// Encoding schema (each variant's JSON representation):
///   ONull               → `{"t":"null"}`
///   OBool(true)         → `{"t":"bool","v":true}`
///   OInt(42)            → `{"t":"int","v":42}`
///   OFloat(3.14)        → `{"t":"float","v":3.14}`
///   OStr("hi")          → `{"t":"str","v":"hi"}`
///   OHtml("...")        → `{"t":"html","v":"..."}`
///   OStorePath(...)     → `{"t":"store_path","path":"/nix/store/..."}`
///   ONixExpr(...)       → `{"t":"nix_expr","source":"..."}`
///   ODerivation(...)    → `{"t":"derivation","drv_path":"...","outputs":{...},...}`
///   OClosure(...)       → `{"t":"closure","root":"...","paths":[...]}`
///   OList([...])        → `{"t":"list","v":[...]}`
///   OMap({...})         → `{"t":"map","v":{...}}`
///   OBlob{..}           → `{"t":"blob","v":"<base64>","mime":"image/png"}`
///
/// The `t` tag is the type discriminant. Most variants carry payload in a
/// `v` field; the Nix-family variants (StorePath, NixExpr, Derivation,
/// Closure) carry semantically-named fields because their internal structure
/// matches Nix tooling output directly (e.g. `nix derivation show`).
///
/// The materialization ladder: NixExpr → Derivation → StorePath → Closure.
/// Each rung is a distinct OValue variant; advancement happens via
/// instantiate / realise / closure operations. A given build can be observed
/// at any rung, which lets policy choose when to materialize.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "t", rename_all = "lowercase")]
pub enum OValue {
    /// The absence of a value. Distinct from false and from zero.
    /// Produced by: void expressions, cleanup operations, null returns.
    Null,

    /// A boolean. No implicit coercions — true is true, false is false.
    #[serde(rename = "bool")]
    Bool { v: bool },

    /// A 64-bit signed integer.
    /// Known limitation: Python/Haskell arbitrary precision integers that
    /// exceed i64::MAX will lose precision. To be fixed with num-bigint.
    #[serde(rename = "int")]
    Int { v: i64 },

    /// A 64-bit IEEE 754 floating point number.
    #[serde(rename = "float")]
    Float { v: f64 },

    /// A UTF-8 string. The most common inter-language value type.
    /// Raw text from backends, spliced $var values, document content —
    /// all arrive as OStr unless the backend explicitly returns something richer.
    #[serde(rename = "str")]
    Str { v: String },
    #[serde(rename = "html")]
    Html  { v: String },
    #[serde(rename = "store_path")]
    StorePath { path: String },

    /// An unevaluated Nix expression, carried as source text.
    ///
    /// This is the *contingent representation* layer of the Nix materialization
    /// ladder. The same artifact can be described by many semantically
    /// equivalent Nix expressions; this variant holds one such description
    /// without committing to any particular evaluation.
    ///
    /// Splice semantics:
    ///   * Into Nix: spliced verbatim (it is already Nix source).
    ///   * Into Python: wrapped as ONixExpr(source) — the Python class is
    ///     opaque on this side; downstream Python decides what to do with it.
    ///   * Into HTML/LaTeX/Markdown: rendered as a code block.
    ///
    /// Lifecycle: produced by nix_expr^(...) blocks and by lazy evaluation
    /// policies that defer materialization. Consumed by `instantiate` (which
    /// produces a Derivation) or by direct splicing into another Nix block.
    #[serde(rename = "nix_expr")]
    NixExpr { source: String },

    /// A Nix derivation — the canonical chart in the materialization category.
    ///
    /// This is *the* L*-analog for build processes. Two semantically identical
    /// Nix expressions produce the same Derivation modulo input-addressing;
    /// every concrete Nix expression pays a positive "definiteness tax" over
    /// the Derivation it instantiates to. Operating at this layer lets O-lang
    /// reason about builds without reference to which Nix expression produced
    /// them.
    ///
    /// Fields mirror the JSON output of `nix derivation show`:
    ///   * drv_path     — the /nix/store/...-foo.drv path of the derivation itself
    ///   * outputs      — named outputs and their realized store paths
    ///   * input_drvs   — other .drv files this depends on, with which outputs used
    ///   * input_srcs   — source store paths this depends on directly
    ///   * system       — target platform (e.g. "x86_64-linux")
    ///   * builder      — store path of the builder program
    ///   * args         — arguments passed to the builder
    ///   * env          — environment variables for the build
    ///
    /// Splice semantics:
    ///   * Into Nix: the .drv path is spliced as a string literal; downstream
    ///     Nix can `import` it, `builtins.storePath` it, or use it as a ref.
    ///   * Into Python: wrapped as ODerivation(drv_path); the Python class can
    ///     re-hydrate the rest of the structure from nix tooling if needed.
    #[serde(rename = "derivation")]
    Derivation {
        drv_path:   String,
        outputs:    HashMap<String, DerivationOutput>,
        input_drvs: HashMap<String, Vec<String>>,
        input_srcs: Vec<String>,
        system:     String,
        builder:    String,
        args:       Vec<String>,
        env:        HashMap<String, String>,
    },

    /// The transitive dependency closure of a store path.
    ///
    /// Computed via `nix-store --query --requisites`. Carries the root path
    /// plus every store path in its transitive runtime closure, topologically
    /// sorted (dependencies before dependents).
    ///
    /// Splice semantics:
    ///   * Default: the root path. Downstream code that needs the full set
    ///     pattern-matches on the variant and reads `paths` directly.
    #[serde(rename = "closure")]
    Closure {
        root:  String,
        paths: Vec<String>,
    },

    /// An ordered, heterogeneous sequence of OValues.
    /// Python lists, Haskell lists, JSON arrays, Racket lists — all map here.
    #[serde(rename = "list")]
    List { v: Vec<OValue> },

    /// A string-keyed map of OValues.
    /// Python dicts, JSON objects, Racket hash tables — all map here.
    /// Keys are ALWAYS strings at the O level. Non-string keys in source
    /// languages must be stringified by their backend shim.
    #[serde(rename = "map")]
    Map { v: HashMap<String, OValue> },

    /// Raw binary data with a MIME type hint for the receiving backend.
    ///
    /// This is the escape hatch for rich values: matplotlib figures,
    /// compiled PDFs, rendered HTML, audio, video, arbitrary binary.
    /// The MIME type carries the rendering semantics:
    ///   "image/png"        → HTML backend renders as <img src="data:...">
    ///   "text/html"        → HTML backend embeds fragment directly
    ///   "application/pdf"  → rendered to file by the output pipeline
    ///
    /// Data is base64-encoded on the wire. The `v` field carries the base64
    /// string; `mime` is a separate field (not inside `v`) because both are
    /// required and neither is "the value" more than the other.
    #[serde(rename = "blob")]
    Blob { v: String, mime: String },   // v = base64-encoded bytes on wire
}


// ═════════════════════════════════════════════════════════════════════════════
// SECTION 2: Constructors
//
// Ergonomic constructors so call sites don't have to write
// OValue::Str { v: "hello".to_string() } everywhere.
// ═════════════════════════════════════════════════════════════════════════════

impl OValue {
    pub fn null()                   -> Self { OValue::Null }
    pub fn bool_(b: bool)           -> Self { OValue::Bool  { v: b } }
    pub fn int(n: i64)              -> Self { OValue::Int   { v: n } }
    pub fn float(f: f64)            -> Self { OValue::Float { v: f } }
    pub fn str_(s: impl Into<String>) -> Self { OValue::Str { v: s.into() } }
    pub fn html(s: impl Into<String>) -> Self { OValue::Html { v: s.into() } }
    pub fn store_path(path: impl Into<String>) -> Self { OValue::StorePath { path: path.into() } }
    pub fn list(items: Vec<OValue>) -> Self { OValue::List  { v: items } }
    pub fn map(entries: HashMap<String, OValue>) -> Self { OValue::Map { v: entries } }

    /// Construct an OValue::NixExpr holding unevaluated Nix source.
    pub fn nix_expr(source: impl Into<String>) -> Self {
        OValue::NixExpr { source: source.into() }
    }

    /// Construct an OValue::Derivation. Most callers will get a Derivation
    /// from `nix derivation show` via the nix_drv backend rather than building
    /// one here, but this constructor is useful in tests and for synthetic
    /// derivations produced by O-lang internals.
    pub fn derivation(
        drv_path:   impl Into<String>,
        outputs:    HashMap<String, DerivationOutput>,
        input_drvs: HashMap<String, Vec<String>>,
        input_srcs: Vec<String>,
        system:     impl Into<String>,
        builder:    impl Into<String>,
        args:       Vec<String>,
        env:        HashMap<String, String>,
    ) -> Self {
        OValue::Derivation {
            drv_path:   drv_path.into(),
            outputs,
            input_drvs,
            input_srcs,
            system:     system.into(),
            builder:    builder.into(),
            args,
            env,
        }
    }

    /// Construct an OValue::Closure with a root path and its transitive deps.
    pub fn closure(root: impl Into<String>, paths: Vec<String>) -> Self {
        OValue::Closure { root: root.into(), paths }
    }

    /// Construct an OBlob from raw bytes and a MIME type.
    /// The bytes are base64-encoded here; the wire representation stores
    /// the base64 string, not the raw bytes.
    pub fn blob(data: &[u8], mime: impl Into<String>) -> Self {
        OValue::Blob {
            v:    B64.encode(data),
            mime: mime.into(),
        }
    }

    /// Decode the raw bytes from an OBlob, reversing the base64 encoding.
    /// Returns None if called on a non-Blob variant.
    pub fn blob_bytes(&self) -> Option<Vec<u8>> {
        match self {
            OValue::Blob { v, .. } => B64.decode(v).ok(),
            _                      => None,
        }
    }

    /// Returns the MIME type of a Blob variant. None for all other variants.
    pub fn blob_mime(&self) -> Option<&str> {
        match self {
            OValue::Blob { mime, .. } => Some(mime.as_str()),
            _                         => None,
        }
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SECTION 3: Type predicates
// ═════════════════════════════════════════════════════════════════════════════

impl OValue {
    pub fn is_null(&self)  -> bool { matches!(self, OValue::Null) }
    pub fn is_bool(&self)  -> bool { matches!(self, OValue::Bool  { .. }) }
    pub fn is_int(&self)   -> bool { matches!(self, OValue::Int   { .. }) }
    pub fn is_float(&self) -> bool { matches!(self, OValue::Float { .. }) }
    pub fn is_str(&self)   -> bool { matches!(self, OValue::Str   { .. }) }
    pub fn is_html(&self) -> bool { matches!(self, OValue::Html { .. }) }
    pub fn is_store_path(&self) -> bool { matches!(self, OValue::StorePath { .. }) }
    pub fn is_nix_expr(&self)   -> bool { matches!(self, OValue::NixExpr   { .. }) }
    pub fn is_derivation(&self) -> bool { matches!(self, OValue::Derivation { .. }) }
    pub fn is_closure(&self)    -> bool { matches!(self, OValue::Closure    { .. }) }
    pub fn is_list(&self)  -> bool { matches!(self, OValue::List  { .. }) }
    pub fn is_map(&self)   -> bool { matches!(self, OValue::Map   { .. }) }
    pub fn is_blob(&self)  -> bool { matches!(self, OValue::Blob  { .. }) }
    pub fn is_numeric(&self) -> bool { self.is_int() || self.is_float() }

    /// True for any variant on the Nix materialization ladder:
    /// NixExpr, Derivation, StorePath, or Closure. Useful for policy code
    /// that decides whether a value can be advanced one rung up the ladder.
    pub fn is_nix_value(&self) -> bool {
        self.is_nix_expr() || self.is_derivation()
            || self.is_store_path() || self.is_closure()
    }

    /// The type name as it appears in the wire protocol `t` field.
    pub fn type_name(&self) -> &'static str {
        match self {
            OValue::Null      => "null",
            OValue::Bool  {..} => "bool",
            OValue::Int   {..} => "int",
            OValue::Float {..} => "float",
            OValue::Str   {..} => "str",
            OValue::Html  { .. } => "html",
            OValue::StorePath  { .. } => "store_path",
            OValue::NixExpr    { .. } => "nix_expr",
            OValue::Derivation { .. } => "derivation",
            OValue::Closure    { .. } => "closure",
            OValue::List  {..} => "list",
            OValue::Map   {..} => "map",
            OValue::Blob  {..} => "blob",
        }
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SECTION 4: Coercions
//
// Safe, explicit coercions from OValue to Rust native types.
// These never panic — they return Result so the caller handles mismatches.
// The O evaluator uses these when splicing values into backend code strings.
// ═════════════════════════════════════════════════════════════════════════════

impl OValue {
    pub fn as_bool(&self) -> Result<bool> {
        match self {
            OValue::Bool { v } => Ok(*v),
            other => bail!("Expected bool, got {}", other.type_name()),
        }
    }

    pub fn as_int(&self) -> Result<i64> {
        match self {
            OValue::Int { v } => Ok(*v),
            other => bail!("Expected int, got {}", other.type_name()),
        }
    }

    pub fn as_float(&self) -> Result<f64> {
        match self {
            OValue::Float { v } => Ok(*v),
            // Implicit int → float widening, because this is always safe
            OValue::Int   { v } => Ok(*v as f64),
            other => bail!("Expected float, got {}", other.type_name()),
        }
    }

    pub fn as_str(&self) -> Result<&str> {
        match self {
            OValue::Str { v } => Ok(v.as_str()),
            other => bail!("Expected str, got {}", other.type_name()),
        }
    }

    pub fn as_list(&self) -> Result<&Vec<OValue>> {
        match self {
            OValue::List { v } => Ok(v),
            other => bail!("Expected list, got {}", other.type_name()),
        }
    }

    pub fn as_map(&self) -> Result<&HashMap<String, OValue>> {
        match self {
            OValue::Map { v } => Ok(v),
            other => bail!("Expected map, got {}", other.type_name()),
        }
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SECTION 5: Splice representation
//
// When an OValue is used as an atom inside a backend's code string — the
// result of evaluating a nested typed expression — it must be converted to
// a string that is syntactically valid in the receiving language.
//
// This is the `$var` splice operation. The representation is conservative:
// it favors forms that are valid in the widest range of languages.
//
// OBlob is special: it splices as a data URI (base64 inline), which is
// valid in HTML, CSS, and as a Python bytes literal prefix.
// ═════════════════════════════════════════════════════════════════════════════

impl OValue {
    /// Convert to a string suitable for splicing into backend source code.
    /// This is what `$var` resolves to when the variable's value is substituted
    /// into the surrounding expression's code string.
    pub fn splice_repr(&self) -> String {
        match self {
            OValue::Null          => "null".to_string(),
            OValue::Bool  { v }   => v.to_string(),
            OValue::Int   { v }   => v.to_string(),
            OValue::Float { v }   => {
                // Always include decimal point — "3" vs "3.0" matters in some langs
                if v.fract() == 0.0 { format!("{:.1}", v) }
                else                 { v.to_string() }
            },
            OValue::Str   { v }   => v.clone(),
            OValue::Html { v } => v.clone(),
            OValue::StorePath { path } => path.clone(),
            // Default splice for a NixExpr: the source verbatim. This is correct
            // when splicing back into a Nix context; other languages override.
            OValue::NixExpr { source } => source.clone(),
            // Default splice for a Derivation: the .drv path. This is the most
            // general handle — downstream code can reference, import, or build
            // against it. Output paths are available structurally via the variant.
            OValue::Derivation { drv_path, .. } => drv_path.clone(),
            // Default splice for a Closure: the root path. The transitive deps
            // are available structurally to code that needs them.
            OValue::Closure { root, .. } => root.clone(),
            OValue::List  { v }   => {
                let items: Vec<String> = v.iter().map(|i| i.splice_repr()).collect();
                format!("[{}]", items.join(", "))
            },
            OValue::Map   { v }   => {
                let pairs: Vec<String> = v.iter()
                    .map(|(k, val)| format!("{:?}: {}", k, val.splice_repr()))
                    .collect();
                format!("{{{}}}", pairs.join(", "))
            },
            OValue::Blob  { v, mime } => {
                format!("data:{};base64,{}", mime, v)
            },
        }
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SECTION 6: Display
//
// Human-readable representation for REPL output and error messages.
// Distinct from splice_repr (which is for code injection) and from the
// JSON wire format (which is for process communication).
// ═════════════════════════════════════════════════════════════════════════════

impl fmt::Display for OValue {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            OValue::Null          => write!(f, "null"),
            OValue::Bool  { v }   => write!(f, "{}", v),
            OValue::Int   { v }   => write!(f, "{}", v),
            OValue::Float { v }   => write!(f, "{}", v),
            OValue::Str   { v }   => write!(f, "{:?}", v),
            OValue::List  { v }   => {
                write!(f, "[")?;
                for (i, item) in v.iter().enumerate() {
                    if i > 0 { write!(f, ", ")?; }
                    write!(f, "{}", item)?;
                }
                write!(f, "]")
            },
            OValue::Map   { v }   => {
                write!(f, "{{")?;
                for (i, (k, val)) in v.iter().enumerate() {
                    if i > 0 { write!(f, ", ")?; }
                    write!(f, "{:?}: {}", k, val)?;
                }
                write!(f, "}}")
            },
            OValue::Html { v } => write!(f, "{}", v),
            OValue::StorePath { path } => write!(f, "{}", path),
            OValue::NixExpr { source } => {
                // Show NixExpr inline-quoted so REPL output is unambiguous,
                // truncating very long sources for readability.
                if source.len() <= 60 {
                    write!(f, "<nix_expr: {:?}>", source)
                } else {
                    write!(f, "<nix_expr: {} chars>", source.len())
                }
            },
            OValue::Derivation { drv_path, outputs, .. } => {
                write!(f, "<derivation: {} ({} outputs)>", drv_path, outputs.len())
            },
            OValue::Closure { root, paths } => {
                write!(f, "<closure: {} + {} deps>", root, paths.len())
            },
            OValue::Blob  { mime, .. } => write!(f, "<blob:{}>", mime),
        }
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SECTION 7: Wire protocol message types
//
// These are the three message types that O's runtime sends to backend
// subprocess shims. The shims respond with OWireResponse.
//
// The protocol is synchronous and line-delimited:
//   → one JSON object per line to the shim's stdin
//   ← one JSON object per line from the shim's stdout
//
// This is intentionally simple. The shim's job is to be thin.
// ═════════════════════════════════════════════════════════════════════════════

/// A command from the O runtime to a backend subprocess shim.
#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "cmd", rename_all = "lowercase")]
pub enum OWireCommand {
    /// Execute a code string in the backend's current environment.
    /// `bindings` are variables to inject before execution — the resolved
    /// values of any `$var` references that appeared in the expression body.
    Exec {
        code:     String,
        bindings: HashMap<String, OValue>,
    },

    /// Clear the backend's environment and release all resources.
    /// Sent when a persistent env [n] is garbage collected, or on shutdown.
    Cleanup,

    /// Verify the backend process is alive and responsive.
    /// Used by the process manager before sending real work.
    Ping,
}

/// A response from a backend subprocess shim to the O runtime.
#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "status", rename_all = "lowercase")]
pub enum OWireResponse {
    /// The command succeeded. `value` is the result as an OValue.
    Ok { value: OValue },

    /// The command failed. `message` is the error text from the backend
    /// (stack trace, compilation error, runtime exception — whatever the
    /// backend's language provides).
    Err { message: String },
}

impl OWireResponse {
    pub fn ok(value: OValue) -> Self {
        OWireResponse::Ok { value }
    }

    pub fn err(message: impl Into<String>) -> Self {
        OWireResponse::Err { message: message.into() }
    }

    pub fn into_result(self) -> Result<OValue> {
        match self {
            OWireResponse::Ok  { value }   => Ok(value),
            OWireResponse::Err { message } => bail!("{}", message),
        }
    }
}


// ═════════════════════════════════════════════════════════════════════════════
// SECTION 8: Error types
// ═════════════════════════════════════════════════════════════════════════════

#[derive(thiserror::Error, Debug)]
pub enum OValueError {
    #[error("Type mismatch: expected {expected}, got {actual}")]
    TypeMismatch { expected: &'static str, actual: String },

    #[error("Base64 decode failed for OBlob: {0}")]
    Base64Error(#[from] base64::DecodeError),

    #[error("JSON serialization error: {0}")]
    JsonError(#[from] serde_json::Error),
}


// ═════════════════════════════════════════════════════════════════════════════
// SECTION 9: Tests
// ═════════════════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;

    /// Every OValue variant must round-trip through JSON without loss.
    /// This test is the foundational correctness guarantee of the wire protocol.
    #[test]
    fn round_trip_all_variants() {
        let cases: Vec<OValue> = vec![
            OValue::null(),
            OValue::bool_(true),
            OValue::bool_(false),
            OValue::int(42),
            OValue::int(-9_999_999_999_999),
            OValue::int(i64::MAX),
            OValue::int(i64::MIN),
            OValue::float(3.14159),
            OValue::float(-0.0),
            // NOTE: f64::INFINITY excluded — JSON RFC 8259 has no infinity repr.
            // serde_json serializes it as null. Custom serializer needed (tracked).
            OValue::str_("hello, world"),
            OValue::str_(""),
            OValue::str_("unicode: こんにちは 🦀"),
            OValue::html("<p>hi</p>"),
            OValue::store_path("/nix/store/abc123-hello"),
            OValue::nix_expr("{ answer = 42; }"),
            OValue::nix_expr(""),
            OValue::closure(
                "/nix/store/root-pkg".to_string(),
                vec![
                    "/nix/store/dep-a".to_string(),
                    "/nix/store/dep-b".to_string(),
                ],
            ),
            {
                let mut outs = HashMap::new();
                outs.insert("out".to_string(), DerivationOutput {
                    path: "/nix/store/abc-out".to_string(),
                    hash_algo: None,
                    hash: None,
                });
                let mut inputs = HashMap::new();
                inputs.insert(
                    "/nix/store/bash.drv".to_string(),
                    vec!["out".to_string()],
                );
                let mut env = HashMap::new();
                env.insert("PATH".to_string(), "/usr/bin".to_string());
                OValue::derivation(
                    "/nix/store/foo.drv",
                    outs,
                    inputs,
                    vec!["/nix/store/builder.sh".to_string()],
                    "x86_64-linux",
                    "/nix/store/bash",
                    vec!["-c".to_string(), "echo hi".to_string()],
                    env,
                )
            },
            // CA-derivation output: hashAlgo and hash present
            {
                let mut outs = HashMap::new();
                outs.insert("out".to_string(), DerivationOutput {
                    path: "/nix/store/ca-out".to_string(),
                    hash_algo: Some("sha256".to_string()),
                    hash: Some("0000000000000000000000000000000000000000000000000000".to_string()),
                });
                OValue::derivation(
                    "/nix/store/ca-foo.drv",
                    outs,
                    HashMap::new(),
                    vec![],
                    "x86_64-linux",
                    "/nix/store/bash",
                    vec![],
                    HashMap::new(),
                )
            },
            OValue::list(vec![
                OValue::int(1),
                OValue::str_("two"),
                OValue::bool_(false),
                OValue::null(),
            ]),
            OValue::map({
                let mut m = HashMap::new();
                m.insert("x".to_string(), OValue::int(10));
                m.insert("y".to_string(), OValue::float(2.5));
                m.insert("nested".to_string(), OValue::list(vec![OValue::null()]));
                m
            }),
            OValue::blob(b"\x89PNG\r\n", "image/png"),
            OValue::blob(&[], "application/octet-stream"),
        ];

        for original in &cases {
            let json    = serde_json::to_string(original)
                .unwrap_or_else(|e| panic!("Serialize failed for {:?}: {}", original, e));
            let decoded: OValue = serde_json::from_str(&json)
                .unwrap_or_else(|e| panic!("Deserialize failed for {}: {}", json, e));
            assert_eq!(*original, decoded,
                "Round-trip failed: {:?} → {} → {:?}", original, json, decoded);
        }
    }

    /// OWireCommand and OWireResponse must also round-trip cleanly,
    /// since they are what actually travels over the subprocess pipe.
    #[test]
    fn round_trip_wire_messages() {
        let mut bindings = HashMap::new();
        bindings.insert("a".to_string(), OValue::int(10));
        bindings.insert("b".to_string(), OValue::str_("hello"));

        let cmd = OWireCommand::Exec {
            code: "print(a + 1)".to_string(),
            bindings,
        };
        let json    = serde_json::to_string(&cmd).unwrap();
        let decoded: OWireCommand = serde_json::from_str(&json).unwrap();
        // Verify the cmd tag is present and correct
        assert!(json.contains(r#""cmd":"exec""#));

        let resp = OWireResponse::ok(OValue::str_("result"));
        let json = serde_json::to_string(&resp).unwrap();
        assert!(json.contains(r#""status":"ok""#));
        let decoded: OWireResponse = serde_json::from_str(&json).unwrap();
        assert!(matches!(decoded, OWireResponse::Ok { .. }));
    }

    /// The type_name method must return the exact string used as the
    /// wire protocol `t` tag — they must stay in sync.
    #[test]
    fn type_names_match_wire_tags() {
        let cases = vec![
            (OValue::null(),          "null"),
            (OValue::bool_(true),     "bool"),
            (OValue::int(0),          "int"),
            (OValue::float(0.0),      "float"),
            (OValue::str_(""),        "str"),
            (OValue::html(""),        "html"),
            (OValue::store_path(""),  "store_path"),
            (OValue::nix_expr(""),    "nix_expr"),
            (OValue::closure("", vec![]), "closure"),
            (OValue::list(vec![]),    "list"),
            (OValue::map(HashMap::new()), "map"),
            (OValue::blob(&[], ""),   "blob"),
        ];
        for (val, expected_tag) in cases {
            assert_eq!(val.type_name(), expected_tag);
            let json: serde_json::Value = serde_json::from_str(
                &serde_json::to_string(&val).unwrap()
            ).unwrap();
            assert_eq!(json["t"].as_str().unwrap(), expected_tag,
                "Wire tag mismatch for {}", expected_tag);
        }

        // Derivation tested separately because it requires sub-structure
        let drv = OValue::derivation(
            "/nix/store/x.drv", HashMap::new(), HashMap::new(),
            vec![], "", "", vec![], HashMap::new(),
        );
        assert_eq!(drv.type_name(), "derivation");
        let json: serde_json::Value = serde_json::from_str(
            &serde_json::to_string(&drv).unwrap()
        ).unwrap();
        assert_eq!(json["t"].as_str().unwrap(), "derivation");
    }

    #[test]
    fn blob_bytes_round_trip() {
        let original_bytes = b"arbitrary binary \x00\x01\x02\xFF data";
        let blob = OValue::blob(original_bytes, "application/octet-stream");
        let recovered = blob.blob_bytes().expect("blob_bytes returned None");
        assert_eq!(original_bytes.as_ref(), recovered.as_slice());
    }

    #[test]
    fn splice_repr_produces_expected_strings() {
        assert_eq!(OValue::null().splice_repr(),       "null");
        assert_eq!(OValue::bool_(true).splice_repr(),  "true");
        assert_eq!(OValue::int(42).splice_repr(),      "42");
        assert_eq!(OValue::float(3.0).splice_repr(),   "3.0");
        assert_eq!(OValue::str_("hi").splice_repr(),   "hi");
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Materialization ladder tests
    //
    // These verify the new Nix-family variants: NixExpr, Derivation, Closure.
    // The discipline they enforce is that each rung of the ladder is a real
    // distinct value with its own type tag, not a stringified collapse.
    // ═════════════════════════════════════════════════════════════════════════

    /// NixExpr carries unevaluated source. The wire shape uses a "source" field
    /// (matching the semantic name) rather than the generic "v" — this is the
    /// signal that NixExpr is structurally distinct from a String, even though
    /// it wraps one.
    #[test]
    fn nix_expr_wire_shape_uses_source_field() {
        let v = OValue::nix_expr("{ x = 1; }");
        let json: serde_json::Value = serde_json::from_str(
            &serde_json::to_string(&v).unwrap()
        ).unwrap();
        assert_eq!(json["t"], "nix_expr");
        assert_eq!(json["source"], "{ x = 1; }");
        assert!(json.get("v").is_none(),
            "NixExpr must NOT serialize with 'v' — that would collapse it into a Str shape");
    }

    /// Derivation matches the shape of `nix derivation show` JSON output, so
    /// the Python shim can deserialize Nix's own output directly into this
    /// type with no transformation layer.
    #[test]
    fn derivation_wire_shape_matches_nix_derivation_show() {
        let mut outs = HashMap::new();
        outs.insert("out".to_string(), DerivationOutput {
            path: "/nix/store/abc-out".to_string(),
            hash_algo: None,
            hash: None,
        });
        let drv = OValue::derivation(
            "/nix/store/foo.drv",
            outs,
            HashMap::new(),
            vec![],
            "x86_64-linux",
            "/nix/store/bash",
            vec![],
            HashMap::new(),
        );
        let json: serde_json::Value = serde_json::from_str(
            &serde_json::to_string(&drv).unwrap()
        ).unwrap();
        assert_eq!(json["t"], "derivation");
        assert_eq!(json["drv_path"], "/nix/store/foo.drv");
        assert_eq!(json["system"], "x86_64-linux");
        assert_eq!(json["builder"], "/nix/store/bash");
        assert_eq!(json["outputs"]["out"]["path"], "/nix/store/abc-out");
        // Optional hash fields are skipped when None — keeps the wire format
        // clean for the common input-addressed case.
        assert!(json["outputs"]["out"].get("hashAlgo").is_none());
        assert!(json["outputs"]["out"].get("hash").is_none());
    }

    /// CA-derivation outputs carry hashAlgo + hash. The wire format uses
    /// camelCase "hashAlgo" to match Nix's own output, not Rust's snake_case.
    #[test]
    fn derivation_output_ca_serialization_uses_camelcase() {
        let out = DerivationOutput {
            path: "/nix/store/ca-out".to_string(),
            hash_algo: Some("sha256".to_string()),
            hash: Some("deadbeef".to_string()),
        };
        let json = serde_json::to_string(&out).unwrap();
        assert!(json.contains("\"hashAlgo\":\"sha256\""),
            "Expected camelCase 'hashAlgo' in: {}", json);
        assert!(json.contains("\"hash\":\"deadbeef\""));
        // And it must round-trip
        let recovered: DerivationOutput = serde_json::from_str(&json).unwrap();
        assert_eq!(out, recovered);
    }

    /// is_nix_value identifies anything on the materialization ladder. This
    /// is what policy code uses to decide "is this value something I can
    /// advance toward greater materialization?"
    #[test]
    fn is_nix_value_recognizes_all_ladder_rungs() {
        assert!(OValue::nix_expr("").is_nix_value());
        assert!(OValue::store_path("").is_nix_value());
        assert!(OValue::closure("", vec![]).is_nix_value());

        let drv = OValue::derivation(
            "", HashMap::new(), HashMap::new(),
            vec![], "", "", vec![], HashMap::new(),
        );
        assert!(drv.is_nix_value());

        // And nothing else
        assert!(!OValue::null().is_nix_value());
        assert!(!OValue::str_("/nix/store/looks-like-a-path").is_nix_value());
        assert!(!OValue::int(42).is_nix_value());
    }

    /// splice_repr for ladder variants picks the most useful default handle.
    /// NixExpr → source verbatim (correct when splicing back into Nix).
    /// Derivation → .drv path (most general handle for downstream code).
    /// Closure → root path (deps are structurally available via the variant).
    #[test]
    fn splice_repr_ladder_variants() {
        assert_eq!(
            OValue::nix_expr("{ x = 1; }").splice_repr(),
            "{ x = 1; }",
        );
        let drv = OValue::derivation(
            "/nix/store/foo.drv", HashMap::new(), HashMap::new(),
            vec![], "", "", vec![], HashMap::new(),
        );
        assert_eq!(drv.splice_repr(), "/nix/store/foo.drv");

        let cl = OValue::closure(
            "/nix/store/root".to_string(),
            vec!["/nix/store/dep1".to_string()],
        );
        assert_eq!(cl.splice_repr(), "/nix/store/root");
    }

    /// Real-world JSON shape from `nix derivation show` must deserialize
    /// directly into OValue::Derivation. This is the contract that lets the
    /// Python shim be thin — Nix tooling output flows in unchanged.
    #[test]
    fn deserialize_from_nix_derivation_show_shape() {
        // Real shape from `nix derivation show /nix/store/...-hello.drv`
        // collapsed to one entry. The outer wrapper map (drv_path → drv body)
        // is unwrapped by the Python shim before this point; what we test
        // here is the body itself plus the "t":"derivation" tag the shim adds.
        let json = r#"{
            "t": "derivation",
            "drv_path": "/nix/store/x-hello.drv",
            "outputs": {
                "out": { "path": "/nix/store/y-hello" }
            },
            "input_drvs": {
                "/nix/store/z-bash.drv": ["out"]
            },
            "input_srcs": ["/nix/store/w-builder.sh"],
            "system": "x86_64-linux",
            "builder": "/nix/store/q-bash",
            "args": ["-e", "/nix/store/w-builder.sh"],
            "env": { "name": "hello", "out": "/nix/store/y-hello" }
        }"#;
        let v: OValue = serde_json::from_str(json)
            .expect("nix derivation show shape must deserialize cleanly");
        assert!(v.is_derivation());
        if let OValue::Derivation { drv_path, outputs, input_drvs, .. } = &v {
            assert_eq!(drv_path, "/nix/store/x-hello.drv");
            assert_eq!(outputs.get("out").unwrap().path, "/nix/store/y-hello");
            assert_eq!(input_drvs.get("/nix/store/z-bash.drv").unwrap(), &vec!["out".to_string()]);
        } else {
            panic!("Expected Derivation variant");
        }
    }

    /// Display format for ladder variants must be readable but not leak
    /// excessive detail. NixExpr truncates long sources; Derivation shows
    /// the .drv path plus output count; Closure shows root + dep count.
    #[test]
    fn display_ladder_variants_is_readable() {
        assert_eq!(
            format!("{}", OValue::nix_expr("{ x = 1; }")),
            "<nix_expr: \"{ x = 1; }\">",
        );
        let long_source = "x".repeat(200);
        assert!(format!("{}", OValue::nix_expr(&long_source)).contains("200 chars"));

        let mut outs = HashMap::new();
        outs.insert("out".to_string(), DerivationOutput {
            path: "/nix/store/y".to_string(),
            hash_algo: None,
            hash: None,
        });
        outs.insert("dev".to_string(), DerivationOutput {
            path: "/nix/store/y-dev".to_string(),
            hash_algo: None,
            hash: None,
        });
        let drv = OValue::derivation(
            "/nix/store/foo.drv", outs, HashMap::new(),
            vec![], "", "", vec![], HashMap::new(),
        );
        let s = format!("{}", drv);
        assert!(s.contains("/nix/store/foo.drv"));
        assert!(s.contains("2 outputs"));

        let cl = OValue::closure(
            "/nix/store/root".to_string(),
            vec!["/nix/store/a".to_string(), "/nix/store/b".to_string()],
        );
        assert_eq!(format!("{}", cl), "<closure: /nix/store/root + 2 deps>");
    }
}
