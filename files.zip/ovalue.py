"""
OValue: the canonical intermediate value representation for .O

Every typed expression in O evaluates to an OValue. Inter-language data
passing MUST serialize through OValue -- this is the runtime embodiment of
the L* canonical form from the Transcompiler Composite Framework's T3
(Intersection) theorem.

Design principles:
  - Structurally rich enough to carry real data (sequences, maps, blobs).
  - Semantically minimal -- no methods, no inheritance, no callbacks.
    OValue is the extensional content of a value, not its behavior.
  - Self-describing via a tag. Every OValue knows what it is.
  - Homoiconic via OExpr: an OValue can carry an unevaluated O AST.
    This is what lets O code produce O code and evaluate it (Lisp-style).

Each language backend is responsible for implementing:
    serialize:   LangNativeValue -> OValue
    deserialize: OValue          -> LangNativeValue
    render:      OValue, target_language -> str

The `render` side is what lets a Python matplotlib figure become an
<img> tag when used as an atom inside an HTML expression -- the HTML
backend knows how to render an OBlob of mime "image/png" into HTML.
"""

from __future__ import annotations

import base64
import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union


# ---------------------------------------------------------------------------
# OValue tagged union
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ONull:
    """The null / unit value. Produced when an expression has no return."""
    tag: str = "null"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "null"}


@dataclass(frozen=True)
class OBool:
    value: bool
    tag: str = "bool"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "bool", "value": self.value}


@dataclass(frozen=True)
class OInt:
    value: int
    tag: str = "int"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "int", "value": self.value}


@dataclass(frozen=True)
class OFloat:
    value: float
    tag: str = "float"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "float", "value": self.value}


@dataclass(frozen=True)
class OStr:
    value: str
    tag: str = "str"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "str", "value": self.value}


@dataclass(frozen=True)
class OList:
    items: Tuple["OValue", ...]
    tag: str = "list"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "list", "items": [v.to_json() for v in self.items]}


@dataclass(frozen=True)
class OMap:
    """Ordered key-value pairs. Keys must be OStr for simplicity in MVP."""
    pairs: Tuple[Tuple[str, "OValue"], ...]
    tag: str = "map"

    def get(self, key: str, default: Optional["OValue"] = None) -> Optional["OValue"]:
        for k, v in self.pairs:
            if k == key:
                return v
        return default

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "map", "pairs": [[k, v.to_json()] for k, v in self.pairs]}


@dataclass(frozen=True)
class OBlob:
    """Opaque binary payload with a mime-type tag.

    This is the crucial constructor that lets a matplotlib figure become an
    <img> tag in HTML, or a LaTeX-compiled PDF become an embedded object in
    another document. The mime tag is the contract the receiving backend
    uses to decide how to render it.
    """
    data: bytes
    mime: str
    tag: str = "blob"

    def to_json(self) -> Dict[str, Any]:
        return {
            "tag": "blob",
            "mime": self.mime,
            "b64": base64.b64encode(self.data).decode("ascii"),
        }


@dataclass(frozen=True)
class OStorePath:
    """A realized Nix store path (e.g. /nix/store/...).

    Carries a path returned by nix_store^(...)_nix_store. It is typed so
    that HTML backends can render it as <code>, Python backends can open()
    it as a real file, and Nix backends can reference it as a store path --
    without any of them confusing it for an ordinary string.
    """
    path: str
    tag: str = "store_path"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "store_path", "path": self.path}


# ---------------------------------------------------------------------------
# Nix materialization ladder: NixExpr -> Derivation -> StorePath -> Closure
#
# These three classes (alongside OStorePath above) form the canonical
# representation of a Nix-tooling artifact at each stage of its lifecycle.
# Policy code uses is_nix_value() to decide whether a value can be advanced
# toward greater materialization. Backends use the structural fields to
# avoid round-tripping through Nix tooling unnecessarily.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DerivationOutput:
    """A single output of a Nix derivation.

    For input-addressed derivations only `path` is populated. For CA-derivations
    and fixed-output derivations, `hash_algo` and `hash` are also populated
    matching the contents of `nix derivation show`.
    """
    path: str
    hash_algo: Optional[str] = None
    hash: Optional[str] = None

    def to_json(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"path": self.path}
        # The wire format uses camelCase "hashAlgo" to match `nix derivation show`
        # output, so the shim can pass Nix's JSON straight through without
        # renaming. Skip when None to keep the wire format compact for the
        # common input-addressed case.
        if self.hash_algo is not None:
            d["hashAlgo"] = self.hash_algo
        if self.hash is not None:
            d["hash"] = self.hash
        return d


@dataclass(frozen=True)
class ONixExpr:
    """An unevaluated Nix expression, carried as source text.

    This is the contingent-representation layer of the materialization
    ladder. The same artifact can be described by many semantically
    equivalent Nix expressions; this class holds one such description
    without committing to any particular evaluation. Produced by
    nix_expr^(...) blocks and by lazy evaluation policies.
    """
    source: str
    tag: str = "nix_expr"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "nix_expr", "source": self.source}


@dataclass(frozen=True)
class ODerivation:
    """A Nix derivation — the canonical chart in the materialization category.

    Fields mirror `nix derivation show` JSON output. This is the L*-analog
    for build processes: two semantically identical Nix expressions produce
    the same Derivation modulo input-addressing, so operating at this layer
    lets O-lang reason about builds without reference to the source
    expression that produced them.
    """
    drv_path: str
    outputs: Tuple[Tuple[str, DerivationOutput], ...] = ()
    input_drvs: Tuple[Tuple[str, Tuple[str, ...]], ...] = ()
    input_srcs: Tuple[str, ...] = ()
    system: str = ""
    builder: str = ""
    args: Tuple[str, ...] = ()
    env: Tuple[Tuple[str, str], ...] = ()
    tag: str = "derivation"

    def output_paths(self) -> Tuple[str, ...]:
        """Convenience accessor: just the output store paths."""
        return tuple(out.path for _, out in self.outputs)

    def get_output(self, name: str = "out") -> Optional[DerivationOutput]:
        """Look up a named output. Defaults to 'out' which most derivations have."""
        for n, out in self.outputs:
            if n == name:
                return out
        return None

    def to_json(self) -> Dict[str, Any]:
        return {
            "tag":        "derivation",
            "drv_path":   self.drv_path,
            "outputs":    {n: o.to_json() for n, o in self.outputs},
            "input_drvs": {p: list(outs)  for p, outs in self.input_drvs},
            "input_srcs": list(self.input_srcs),
            "system":     self.system,
            "builder":    self.builder,
            "args":       list(self.args),
            "env":        {k: v for k, v in self.env},
        }


@dataclass(frozen=True)
class OClosure:
    """The transitive runtime closure of a store path.

    Carries the root path plus every store path in its transitive dependency
    closure, topologically sorted (dependencies before dependents). Computed
    via `nix-store --query --requisites`.
    """
    root: str
    paths: Tuple[str, ...] = ()
    tag: str = "closure"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "closure", "root": self.root, "paths": list(self.paths)}


@dataclass(frozen=True)
class OExpr:
    """An unevaluated O expression, carried as a value.

    This is what gives O meta-level homoiconicity: an O program can produce
    an O AST as a value, hand it to another expression, and have it
    evaluated. This is Lisp's quote/eval generalized across the multi-
    language system.

    We carry the AST reference as an arbitrary Python object so we don't
    create an import cycle with parser.py. The evaluator will type-check
    at eval time.
    """
    ast: Any                    # Really an ExpressionNode from parser.py
    tag: str = "expr"

    def to_json(self) -> Dict[str, Any]:
        return {"tag": "expr", "repr": repr(self.ast)}


OValue = Union[
    ONull, OBool, OInt, OFloat, OStr, OStorePath,
    ONixExpr, ODerivation, OClosure,
    OList, OMap, OBlob, OExpr,
]


# Convenience tuple used for isinstance() checks throughout the codebase.
# Centralized here so adding a new variant only requires updating one place.
_O_VALUE_TYPES: Tuple[type, ...] = (
    ONull, OBool, OInt, OFloat, OStr, OStorePath,
    ONixExpr, ODerivation, OClosure,
    OList, OMap, OBlob, OExpr,
)


def is_nix_value(v: Any) -> bool:
    """Mirrors OValue::is_nix_value() in src/value.rs.

    True for any value on the Nix materialization ladder:
    ONixExpr, ODerivation, OStorePath, or OClosure.
    Used by policy code (lazy/eager/autonomous evaluation) to decide whether
    a value can be advanced toward greater materialization.
    """
    return isinstance(v, (ONixExpr, ODerivation, OStorePath, OClosure))


# ---------------------------------------------------------------------------
# Python <-> OValue conversion helpers
# ---------------------------------------------------------------------------

def from_python(x: Any) -> OValue:
    """Best-effort lifting of a Python value into OValue.

    Backends will typically call this on the last-expression value returned
    by their interpreter when they don't have a more specific encoding.
    """
    # Already an OValue? Pass through unchanged so that Python code can
    # build up heterogeneous lists of OInt/OStr/OBlob without us stringifying
    # them on the way out.
    if isinstance(x, _O_VALUE_TYPES):
        return x
    if x is None:
        return ONull()
    if isinstance(x, bool):         # must come before int -- bool is an int subclass
        return OBool(x)
    if isinstance(x, int):
        return OInt(x)
    if isinstance(x, float):
        return OFloat(x)
    if isinstance(x, str):
        return OStr(x)
    if isinstance(x, bytes):
        return OBlob(x, "application/octet-stream")
    if isinstance(x, (list, tuple)):
        return OList(tuple(from_python(v) for v in x))
    if isinstance(x, dict):
        return OMap(tuple((str(k), from_python(v)) for k, v in x.items()))
    # Fallback: stringify. A richer implementation would have registered
    # adapters here (e.g., matplotlib.figure.Figure -> OBlob("image/png")).
    return OStr(repr(x))


def to_python(v: OValue) -> Any:
    """Lower an OValue back into a Python native value.

    Note that materialization-ladder variants (ONixExpr, ODerivation, OClosure)
    lower to a useful default Python representation but lose the type identity.
    Code that needs the typed form should isinstance-check the OValue directly
    rather than going through to_python.
    """
    if isinstance(v, ONull):
        return None
    if isinstance(v, (OBool, OInt, OFloat, OStr)):
        return v.value
    if isinstance(v, OStorePath):
        return v.path
    if isinstance(v, ONixExpr):
        return v.source
    if isinstance(v, ODerivation):
        return v.drv_path
    if isinstance(v, OClosure):
        return v.root
    if isinstance(v, OList):
        return [to_python(item) for item in v.items]
    if isinstance(v, OMap):
        return {k: to_python(val) for k, val in v.pairs}
    if isinstance(v, OBlob):
        return v.data
    if isinstance(v, OExpr):
        return v.ast
    raise TypeError(f"Unknown OValue tag: {v!r}")


def to_json_str(v: OValue, indent: Optional[int] = 2) -> str:
    """Serialize an OValue to a JSON string for logging / debugging."""
    return json.dumps(v.to_json(), indent=indent)


# ---------------------------------------------------------------------------
# Generic "render to string" fallback
# ---------------------------------------------------------------------------

def render_plain(v: OValue) -> str:
    """Default rendering used when no backend-specific renderer applies.

    Scalars become their str(), lists/maps become JSON, blobs become a
    placeholder marker. Backends are free to override this for their own
    target language.
    """
    if isinstance(v, ONull):
        return ""
    if isinstance(v, (OBool, OInt, OFloat)):
        return str(v.value)
    if isinstance(v, OStr):
        return v.value
    if isinstance(v, OStorePath):
        return v.path
    if isinstance(v, ONixExpr):
        return v.source
    if isinstance(v, ODerivation):
        return v.drv_path
    if isinstance(v, OClosure):
        return v.root
    if isinstance(v, OList):
        return "[" + ", ".join(render_plain(x) for x in v.items) + "]"
    if isinstance(v, OMap):
        return "{" + ", ".join(f"{k}: {render_plain(x)}" for k, x in v.pairs) + "}"
    if isinstance(v, OBlob):
        return f"<blob mime={v.mime} bytes={len(v.data)}>"
    if isinstance(v, OExpr):
        return f"<expr {v.ast!r}>"
    return str(v)
