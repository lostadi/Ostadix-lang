#!/usr/bin/env python3
"""
Nix derivation shim — the producer of OValue::Derivation.

This is the wire-protocol backend for `drv^(...)_drv` blocks. It evaluates a
Nix expression that produces a derivation (a derivation value, or any
expression evaluating to one), then emits the canonical .drv structure as
an OValue::Derivation via the wire format.

The pipeline:
    Nix expression source
      → nix-instantiate         (produces /nix/store/...-foo.drv)
      → nix derivation show     (produces canonical JSON)
      → OValue::Derivation

This is the entry point to the materialization category at its canonical
layer. Working at this layer means O-lang reasons about builds without
reference to which Nix expression produced them — two expressions that
instantiate to the same .drv are indistinguishable here, which is exactly
the TCF discipline applied to materialization.

Notes:
  * Requires nix with experimental features `nix-command` enabled.
  * `nix-instantiate` is the canonical projection: NixExpr → Derivation.
  * `nix derivation show` may return multiple drvs (with --recursive); we
    use the non-recursive default which returns just the requested .drv.
  * The shim is stateless. Each exec runs a fresh nix-instantiate
    invocation. The materialization-discipline rationale: every .drv has
    a content-addressed identity, so two identical expressions produce
    the same .drv path regardless of when they were instantiated. State
    would be a category error.
"""
import sys
import json
import subprocess
import traceback


def send_ok(value):
    print(json.dumps({"status": "ok", "value": value}), flush=True)


def send_err(message):
    print(json.dumps({"status": "err", "message": message}), flush=True)


def instantiate_to_drv_path(expr_source):
    """Run nix-instantiate to produce a .drv store path from Nix source.

    nix-instantiate writes the .drv path(s) to stdout. For a single
    derivation expression, this is one line: the /nix/store/...-foo.drv path.
    """
    cmd = [
        "nix-instantiate",
        "--expr",
        expr_source,
    ]
    completed = subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            "nix-instantiate failed\n\nSTDERR:\n"
            + completed.stderr
            + "\nSTDOUT:\n"
            + completed.stdout
        )

    # nix-instantiate may print multiple .drv paths if the expression
    # evaluates to a list of derivations; for the canonical case we expect
    # exactly one. Take the first; surface a warning hint in the error path
    # if there were more.
    lines = [ln.strip() for ln in completed.stdout.splitlines() if ln.strip()]
    if not lines:
        raise RuntimeError(
            "nix-instantiate produced no .drv path. The expression may not "
            "evaluate to a derivation."
        )
    drv_path = lines[0]
    if not drv_path.startswith("/nix/store/") or not drv_path.endswith(".drv"):
        raise RuntimeError(
            f"nix-instantiate produced an unexpected path: {drv_path!r}"
        )
    return drv_path


def show_derivation(drv_path):
    """Run `nix derivation show` and parse its JSON output.

    Returns the inner derivation object — i.e. the value at the .drv-path
    key of the top-level map that `nix derivation show` emits. This is the
    canonical shape that maps directly onto OValue::Derivation.
    """
    cmd = [
        "nix",
        "--extra-experimental-features",
        "nix-command",
        "derivation",
        "show",
        drv_path,
    ]
    completed = subprocess.run(
        cmd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            "nix derivation show failed\n\nSTDERR:\n"
            + completed.stderr
            + "\nSTDOUT:\n"
            + completed.stdout
        )

    parsed = json.loads(completed.stdout)
    # The top-level shape is { "/nix/store/...-foo.drv": { ...fields... } }.
    # We unwrap to the inner object since the wire-format Derivation embeds
    # the drv_path as a field rather than a key.
    if drv_path not in parsed:
        raise RuntimeError(
            f"nix derivation show output did not contain expected key {drv_path!r}; "
            f"got keys: {list(parsed)}"
        )
    return parsed[drv_path]


def derivation_to_oval(drv_path, body):
    """Construct an OValue::Derivation from `nix derivation show` output.

    The body shape matches the Rust struct field-for-field. We pass through
    Nix's own field names (camelCase `hashAlgo` inside outputs is preserved
    by the Rust serde derive) so no transformation layer is needed.
    """
    return {
        "t":          "derivation",
        "drv_path":   drv_path,
        "outputs":    body.get("outputs", {}),
        "input_drvs": _normalize_input_drvs(body.get("inputDrvs", {})),
        "input_srcs": body.get("inputSrcs", []),
        "system":     body.get("system", ""),
        "builder":    body.get("builder", ""),
        "args":       body.get("args", []),
        "env":        body.get("env", {}),
    }


def _normalize_input_drvs(input_drvs):
    """`nix derivation show` may emit inputDrvs values as either a flat list
    of output names (older Nix) or as {"dynamicOutputs": ..., "outputs": [...]}
    (newer Nix with dynamic derivations).

    We normalize to a flat list of output names — the simpler shape — so
    downstream code sees a uniform format. If the newer shape is encountered,
    the static outputs list is taken; dynamic outputs are out of scope for
    the MVP and will be handled when CA-derivations land more broadly.
    """
    out = {}
    for drv, value in input_drvs.items():
        if isinstance(value, list):
            out[drv] = value
        elif isinstance(value, dict):
            # Newer Nix shape: take the static outputs.
            out[drv] = list(value.get("outputs", []))
        else:
            out[drv] = []
    return out


def handle_exec(cmd):
    code = cmd.get("code", "")

    try:
        drv_path = instantiate_to_drv_path(code)
        body     = show_derivation(drv_path)
        oval     = derivation_to_oval(drv_path, body)
        print(json.dumps({"status": "ok", "value": oval}), flush=True)
    except Exception:
        send_err(traceback.format_exc())


def handle_ping():
    print(json.dumps({"status": "ok", "value": {"t": "null"}}), flush=True)


def handle_cleanup():
    # Stateless backend — nothing to clean up. Confirm with null.
    print(json.dumps({"status": "ok", "value": {"t": "null"}}), flush=True)


for line in sys.stdin:
    try:
        cmd = json.loads(line)
        tag = cmd.get("cmd")

        if tag == "exec":
            handle_exec(cmd)
        elif tag == "ping":
            handle_ping()
        elif tag == "cleanup":
            handle_cleanup()
        else:
            send_err(f"unknown command: {tag!r}")

    except Exception:
        send_err(traceback.format_exc())
