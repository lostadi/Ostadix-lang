; This is purely data. OValue struct definitions and their JSON encoding/decoding.
; No evaluation, no parsing, no subprocesses. Just the type system and its wire
; representation.
;
; Updated to reflect the materialization ladder: NixExpr → Derivation →
; StorePath → Closure. Each rung is a distinct OValue variant.

#lang racket/base
(require racket/match json)

;; OValue is one of:
(struct o-null       ()                  #:transparent)
(struct o-bool       (v)                 #:transparent)
(struct o-int        (v)                 #:transparent)
(struct o-float      (v)                 #:transparent)
(struct o-str        (v)                 #:transparent)
(struct o-html       (v)                 #:transparent)  ; trusted HTML fragment
(struct o-list       (items)             #:transparent)
(struct o-map        (entries)           #:transparent)  ; entries: hash string->OValue
(struct o-blob       (data mime)         #:transparent)  ; data: bytes

;; Nix materialization ladder:
;;   o-nix-expr     unevaluated source              (contingent representation)
;;   o-derivation   canonical chart (.drv content)  (L*-analog: zero excess entropy)
;;   o-store-path   realized terminal artifact      (input- or content-addressed)
;;   o-closure      transitive runtime dep closure  (root + topo-sorted deps)
(struct o-store-path (path)              #:transparent)
(struct o-nix-expr   (source)            #:transparent)
(struct o-derivation (drv-path           ; "/nix/store/...-foo.drv"
                      outputs            ; hash: output-name -> o-drv-output
                      input-drvs         ; hash: .drv path -> (listof output-name)
                      input-srcs         ; (listof store-path-string)
                      system             ; "x86_64-linux", etc.
                      builder            ; "/nix/store/...-bash"
                      args               ; (listof string)
                      env)               ; hash: var name -> string value
                     #:transparent)
(struct o-closure    (root paths)        #:transparent)  ; paths: (listof string)

;; Sub-record carried inside o-derivation.outputs values.
;; hash-algo and hash are #f for input-addressed derivations,
;; populated for CA-derivations and fixed-output derivations.
(struct o-drv-output (path hash-algo hash) #:transparent)


;; ─────────────────────────────────────────────────────────────────────────────
;; OValue -> JSON
;;
;; Each variant produces an object with a "t" type-tag and variant-specific
;; payload fields. The Rust runtime uses serde-derived encoding with these
;; same tags; this Racket spec is the canonical reference for what the wire
;; bytes look like.
;; ─────────────────────────────────────────────────────────────────────────────

(define (oval->jsexpr v)
  (match v
    [(o-null)        (hasheq 't "null")]
    [(o-bool b)      (hasheq 't "bool"  'v b)]
    [(o-int n)       (hasheq 't "int"   'v n)]
    [(o-float f)     (hasheq 't "float" 'v f)]
    [(o-str s)       (hasheq 't "str"   'v s)]
    [(o-html s)      (hasheq 't "html"  'v s)]
    [(o-list items)  (hasheq 't "list"  'v (map oval->jsexpr items))]
    [(o-map entries) (hasheq 't "map"   'v (hash-map/copy entries
                                             (λ (k v) (values k (oval->jsexpr v)))))]
    [(o-blob d mime) (hasheq 't "blob"  'v (base64-encode d) 'mime mime)]

    ;; Materialization ladder
    [(o-store-path p)
     (hasheq 't "store_path" 'path p)]

    [(o-nix-expr src)
     ;; "source" not "v" — semantic field name preserves type identity on the wire
     (hasheq 't "nix_expr" 'source src)]

    [(o-derivation dp outs in-drvs in-srcs sys bld args env)
     (hasheq 't          "derivation"
             'drv_path   dp
             'outputs    (hash-map/copy outs
                           (λ (k o) (values k (drv-output->jsexpr o))))
             'input_drvs in-drvs
             'input_srcs in-srcs
             'system     sys
             'builder    bld
             'args       args
             'env        env)]

    [(o-closure root paths)
     (hasheq 't "closure" 'root root 'paths paths)]))

(define (drv-output->jsexpr o)
  ;; Matches `nix derivation show` JSON: path always present;
  ;; hashAlgo+hash present only for CA/fixed-output derivations.
  (let* ([base (hasheq 'path (o-drv-output-path o))]
         [with-algo (if (o-drv-output-hash-algo o)
                        (hash-set base 'hashAlgo (o-drv-output-hash-algo o))
                        base)]
         [with-hash (if (o-drv-output-hash o)
                        (hash-set with-algo 'hash (o-drv-output-hash o))
                        with-algo)])
    with-hash))


;; ─────────────────────────────────────────────────────────────────────────────
;; JSON -> OValue
;; ─────────────────────────────────────────────────────────────────────────────

(define (jsexpr->oval j)
  (match (hash-ref j 't)
    ["null"       (o-null)]
    ["bool"       (o-bool  (hash-ref j 'v))]
    ["int"        (o-int   (hash-ref j 'v))]
    ["float"      (o-float (hash-ref j 'v))]
    ["str"        (o-str   (hash-ref j 'v))]
    ["html"       (o-html  (hash-ref j 'v))]
    ["list"       (o-list  (map jsexpr->oval (hash-ref j 'v)))]
    ["map"        (o-map   (hash-map/copy (hash-ref j 'v)
                             (λ (k v) (values k (jsexpr->oval v)))))]
    ["blob"       (o-blob  (base64-decode (hash-ref j 'v))
                           (hash-ref j 'mime))]
    ["store_path" (o-store-path (hash-ref j 'path))]
    ["nix_expr"   (o-nix-expr   (hash-ref j 'source))]
    ["derivation"
     (o-derivation (hash-ref j 'drv_path)
                   (hash-map/copy (hash-ref j 'outputs)
                     (λ (k v) (values k (jsexpr->drv-output v))))
                   (hash-ref j 'input_drvs)
                   (hash-ref j 'input_srcs)
                   (hash-ref j 'system)
                   (hash-ref j 'builder)
                   (hash-ref j 'args)
                   (hash-ref j 'env))]
    ["closure"
     (o-closure (hash-ref j 'root) (hash-ref j 'paths))]))

(define (jsexpr->drv-output j)
  (o-drv-output (hash-ref j 'path)
                (hash-ref j 'hashAlgo #f)
                (hash-ref j 'hash     #f)))


;; ─────────────────────────────────────────────────────────────────────────────
;; Materialization-ladder predicate.
;;
;; Mirrors OValue::is_nix_value() in src/value.rs. Returns #t for anything on
;; the ladder (nix-expr, derivation, store-path, closure), #f otherwise.
;; Used by policy code that decides whether a value can be advanced toward
;; greater materialization.
;; ─────────────────────────────────────────────────────────────────────────────

(define (nix-value? v)
  (or (o-nix-expr?   v)
      (o-derivation? v)
      (o-store-path? v)
      (o-closure?    v)))


(provide (all-defined-out))
