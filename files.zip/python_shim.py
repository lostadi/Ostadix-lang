#!/usr/bin/env python3
"""
Python subprocess shim used by the Rust runtime.

Receives line-delimited JSON commands on stdin, executes them in a persistent
Python env, and writes line-delimited JSON responses to stdout.

This file is the wire-protocol membrane between the Rust runtime and the
Python evaluator. The classes defined here (OHtml, OStorePath, ONixExpr,
ODerivation, OClosure) are injected into the user's exec namespace so that
splice-rendered code like `path = OStorePath("/nix/store/...")` is valid
Python that produces a typed instance — not a bare string.
"""
import sys
import json
import io
import contextlib
import base64
import traceback


# ─────────────────────────────────────────────────────────────────────────────
# Typed wrappers exposed to user Python code.
#
# These mirror the OValue variants in src/value.rs. The simple ones (OHtml,
# OStorePath, ONixExpr) are str subclasses so they interoperate naturally
# with string-handling code while preserving type identity for round-trip
# back to the Rust side. ODerivation and OClosure are structured because
# they carry multi-field data that wouldn't fit a string wrapper cleanly.
# ─────────────────────────────────────────────────────────────────────────────

class OHtml(str):
    """Typed trusted HTML fragment passed through O-lang."""
    def __new__(cls, value):
        return str.__new__(cls, value)


class OStorePath(str):
    """Typed Nix store path passed through O-lang.

    Behaves as a string for file-system operations (open, os.path.*) while
    preserving its store-path identity for backend-specific rendering.
    """
    def __new__(cls, value):
        return str.__new__(cls, value)


class ONixExpr(str):
    """Unevaluated Nix expression source.

    A str subclass so user code can manipulate the source as text, but
    typed so it round-trips back through the wire as nix_expr rather than
    collapsing into a plain str.
    """
    def __new__(cls, source):
        return str.__new__(cls, source)


class ODerivation:
    """A Nix derivation — canonical chart in the materialization category.

    Carries the .drv path always; the structural fields (outputs, input_drvs,
    etc.) are populated when the Rust side has them and empty otherwise.
    This means the Python class can be constructed cheaply from just a path
    (the splice-time form) and the lazy-fill pattern is supported.

    Use get_output("out") to retrieve a named output's path. For the most
    common case where you just want a usable file path, .out_path is the
    shortcut.
    """
    __slots__ = ("drv_path", "outputs", "input_drvs", "input_srcs",
                 "system", "builder", "args", "env")

    def __init__(self, drv_path, outputs=None, input_drvs=None,
                 input_srcs=None, system="", builder="",
                 args=None, env=None):
        self.drv_path   = drv_path
        # outputs: { name: {"path": ..., "hashAlgo"?: ..., "hash"?: ...} }
        self.outputs    = dict(outputs    or {})
        self.input_drvs = dict(input_drvs or {})
        self.input_srcs = list(input_srcs or [])
        self.system     = system
        self.builder    = builder
        self.args       = list(args or [])
        self.env        = dict(env  or {})

    def get_output(self, name="out"):
        """Return the dict for a named output, or None if absent."""
        return self.outputs.get(name)

    @property
    def out_path(self):
        """Path of the default 'out' output, or None if not realized."""
        out = self.outputs.get("out")
        return out["path"] if out else None

    def __repr__(self):
        return f"ODerivation({self.drv_path!r}, outputs={list(self.outputs)})"

    def __str__(self):
        return self.drv_path


class OClosure:
    """Transitive runtime dependency closure rooted at a store path."""
    __slots__ = ("root", "paths")

    def __init__(self, root, paths=None):
        self.root  = root
        self.paths = list(paths or [])

    def __len__(self):
        return len(self.paths)

    def __contains__(self, path):
        return path in self.paths

    def __repr__(self):
        return f"OClosure({self.root!r}, paths=[{len(self.paths)} items])"

    def __str__(self):
        return self.root


# ─────────────────────────────────────────────────────────────────────────────
# Injected user-code namespace.
#
# These names are visible inside python^(...)_python blocks. When the Rust
# side splice-renders an OValue::Derivation as `ODerivation("/nix/store/...")`
# the user's exec sees that as a constructor call against this class.
# ─────────────────────────────────────────────────────────────────────────────

def _initial_env():
    """The set of names injected after every cleanup. Kept separate so the
    cleanup handler can rebuild a fresh env without forgetting to inject one."""
    return {
        "OHtml":       OHtml,
        "OStorePath":  OStorePath,
        "ONixExpr":    ONixExpr,
        "ODerivation": ODerivation,
        "OClosure":    OClosure,
    }


env = _initial_env()


# ─────────────────────────────────────────────────────────────────────────────
# Wire -> Python
# ─────────────────────────────────────────────────────────────────────────────

def oval_to_py(v):
    t = v.get("t")

    if t == "null":
        return None
    if t == "bool":
        return bool(v.get("v"))
    if t == "int":
        return int(v.get("v"))
    if t == "float":
        return float(v.get("v"))
    if t == "str":
        return str(v.get("v"))
    if t == "html":
        return OHtml(v.get("v", ""))
    if t == "store_path":
        return OStorePath(v.get("path", ""))
    if t == "nix_expr":
        return ONixExpr(v.get("source", ""))
    if t == "derivation":
        return ODerivation(
            drv_path=   v.get("drv_path", ""),
            outputs=    v.get("outputs", {}),
            input_drvs= v.get("input_drvs", {}),
            input_srcs= v.get("input_srcs", []),
            system=     v.get("system", ""),
            builder=    v.get("builder", ""),
            args=       v.get("args", []),
            env=        v.get("env", {}),
        )
    if t == "closure":
        return OClosure(
            root=  v.get("root", ""),
            paths= v.get("paths", []),
        )
    if t == "list":
        return [oval_to_py(x) for x in v.get("v", [])]
    if t == "map":
        return {k: oval_to_py(x) for k, x in v.get("v", {}).items()}
    if t == "blob":
        return base64.b64decode(v.get("v", ""))

    raise ValueError(f"unknown OValue type: {t!r}")


# ─────────────────────────────────────────────────────────────────────────────
# Python -> Wire
#
# Order matters: more specific subclasses must be checked before their
# parents. ONixExpr / OStorePath / OHtml are str subclasses so they come
# before the generic str case. bool is an int subclass so it comes first
# among the numerics.
# ─────────────────────────────────────────────────────────────────────────────

def py_to_oval(x):
    if x is None:
        return {"t": "null"}

    if isinstance(x, bool):
        return {"t": "bool", "v": x}

    if isinstance(x, int):
        return {"t": "int", "v": x}

    if isinstance(x, float):
        return {"t": "float", "v": x}

    # Structured Nix types first — these aren't str subclasses
    if isinstance(x, ODerivation):
        return {
            "t":          "derivation",
            "drv_path":   x.drv_path,
            "outputs":    x.outputs,
            "input_drvs": x.input_drvs,
            "input_srcs": x.input_srcs,
            "system":     x.system,
            "builder":    x.builder,
            "args":       x.args,
            "env":        x.env,
        }

    if isinstance(x, OClosure):
        return {"t": "closure", "root": x.root, "paths": x.paths}

    # Now the str-subclass typed wrappers — must come before bare str
    if isinstance(x, OHtml):
        return {"t": "html", "v": str(x)}

    if isinstance(x, OStorePath):
        return {"t": "store_path", "path": str(x)}

    if isinstance(x, ONixExpr):
        return {"t": "nix_expr", "source": str(x)}

    if isinstance(x, str):
        return {"t": "str", "v": x}

    if isinstance(x, bytes):
        return {
            "t":    "blob",
            "v":    base64.b64encode(x).decode("ascii"),
            "mime": "application/octet-stream",
        }

    if isinstance(x, (list, tuple)):
        return {"t": "list", "v": [py_to_oval(i) for i in x]}

    if isinstance(x, dict):
        return {"t": "map", "v": {str(k): py_to_oval(v) for k, v in x.items()}}

    return {"t": "str", "v": str(x)}


# ─────────────────────────────────────────────────────────────────────────────
# Command handlers
# ─────────────────────────────────────────────────────────────────────────────

def send_ok(value=None):
    print(json.dumps({"status": "ok", "value": py_to_oval(value)}), flush=True)


def send_err(message):
    print(json.dumps({"status": "err", "message": message}), flush=True)


def handle_exec(cmd):
    code     = cmd.get("code", "")
    bindings = cmd.get("bindings", {})

    for name, oval in bindings.items():
        env[name] = oval_to_py(oval)

    buf = io.StringIO()

    try:
        with contextlib.redirect_stdout(buf):
            exec(code, env, env)

        if "__oval_result__" in env:
            result = env.pop("__oval_result__")
        else:
            result = buf.getvalue()

        send_ok(result)

    except Exception:
        send_err(traceback.format_exc())


def handle_cleanup():
    env.clear()
    env.update(_initial_env())
    send_ok(None)


def handle_ping():
    send_ok(None)


for line in sys.stdin:
    try:
        cmd = json.loads(line)
        tag = cmd.get("cmd")

        if tag == "exec":
            handle_exec(cmd)
        elif tag == "cleanup":
            handle_cleanup()
        elif tag == "ping":
            handle_ping()
        else:
            send_err(f"unknown command: {tag!r}")

    except Exception:
        send_err(traceback.format_exc())
